package main.java.tddt;

import main.java.tddt.gui.GUIMain;


public class TestDrivenDevelopmentTrainer {
    public static void main(String[] args){
        GUIMain.launchGUI(args);
    }
}
